package isort;/*
 * @author zq
 */


public class BubbleSort extends BaseIntSort {

    @Override
    protected Integer[] sort(Integer[] arr) {

        //冒泡
        bobbleSort(arr);

        return arr;
    }

    private static void bobbleSort(Integer[] arr){
        int length = arr.length;
        for (int i = 0; i < length; i++) {
            for (int j = 0; j < length - i - 1; j++) {
                if(arr[j]>arr[j+1]){
                    int swap = arr[j];
                    arr[j] = arr[j+1];
                    arr[j+1] = swap;
                }
            }
        }
    }

}
