package isort;/*
 * @author zq
 */

public class ChooseSort extends BaseIntSort {

    @Override
    protected Integer[] sort(Integer[] arr) {
        //选择排序
        chooseSort(arr);
        return arr;
    }

    private static void chooseSort(Integer[] arr){
        int length = arr.length;
        for (int i = 0; i < length; i++) {
            for (int j = i; j < length; j++) {
                if(arr[i] > arr[j]){
                    int swap = arr[i];
                    arr[i] = arr[j];
                    arr[j] = swap;
                }
            }
        }
    }
}

