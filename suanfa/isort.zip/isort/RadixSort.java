package isort;/*
 * @author zq
 */

public class RadixSort extends BaseIntSort{

    @Override
    public Integer[] sort(Integer[] arr) {

        bucketSort(arr);

        return arr;
    }

    private static int[][] bucket;

    //记录一下每个桶中有多少元素
    private static int[] bucketCount = new int[10];

    //正负数数组
    private static Integer [] positiveArr ;
    private static Integer [] negativeArr ;


    private static void bucketSort(Integer[] arr){
        //创建桶
        bucket = new int[10][arr.length];

        initSonArr(arr);

        int max = arr[0];
        int min = arr[0];
        for (int anArr : arr) {
            if (anArr < min) {
                min = anArr;
            }
            if(anArr > max){
                max = anArr;
            }
        }

        if(negativeArr.length > 0){
            //说明有负数开始装桶
            inputBucket(min,negativeArr);

            for (int i = 0,j = negativeArr.length - 1; i <negativeArr.length; i++) {
                arr[i] = negativeArr[j--];
            }
        }

        if(positiveArr.length > 0){
            inputBucket(max,positiveArr);
            for (int i = negativeArr.length,j = 0; i < arr.length; i++) {
                arr[i] = positiveArr[j++];
            }
        }

    }

    private static void initSonArr(Integer[] arr){
        int positiveSize = 0;
        int negativeSize = 0;

        for (Integer anArr : arr) {
            if (anArr < 0) {
                negativeSize++;
            } else {
                positiveSize++;
            }
        }

        positiveArr = new Integer[positiveSize];
        negativeArr = new Integer[negativeSize];

        for (int i = 0,n=0,m=0;i<arr.length;i++) {
            if(arr[i] < 0){
                negativeArr[n++] = arr[i];
            } else {
                positiveArr[m++] = arr[i];
            }
        }
    }

    private static void inputBucket(int max,Integer[] targetArr){
        //获取最大或最小值位数
        int maxLength = String.valueOf(Math.abs(max)).length();
        //开始装桶
        // n用于记录当前是根据那一位放入桶中的1代表个位10代表十位...
        for (int i = 0,n = 1; i < maxLength; i++, n *= 10) {
            int k; //用来记录数组中元素的某位的数用于判断(如32,若n==1则为2,n==10则为3)

            //将arr中的值放入桶中
            for (Integer a : targetArr) {
                k = Math.abs(a) / n % 10;
                bucket[k][bucketCount[k]] = a;
                bucketCount[k]++;
            }

            //遍历桶取出数据放回数组中
            for(int p = 0,q = 0; p < bucket.length; ++p) {
                if (bucketCount[p] != 0) {
                    for(int r = 0; r < bucketCount[p]; ++r) {
                        targetArr[q] = bucket[p][r];
                        ++q;
                    }
                }

                bucketCount[p] = 0;
            }
        }
    }
}
