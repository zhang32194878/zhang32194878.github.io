package isort;/*
 * @author zq
 */

public class InsertSort extends BaseIntSort {

    @Override
    protected Integer[] sort(Integer[] arr) {
        //选择排序
        insertSort(arr);
        return arr;
    }

    private static void insertSort(Integer[] arr){
        int length = arr.length;
        for (int i = 0; i < length; i++) {
            int temp = arr[i]; // 记录要插入的数据
            int j = i; //记录要插入的位置
            while(j > 0 && arr[j - 1] > temp) {
                arr[j] = arr[j-1]; //给要插入的数据挪位置
                j--;
            }
            if(j != i){
                arr[j] = temp;
            }
        }
    }
}
