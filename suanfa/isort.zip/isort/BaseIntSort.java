package isort;/*
 * @author zq
 */


import java.util.Arrays;

public abstract class BaseIntSort implements IArraySort<Integer> {

    Integer[] sortOf(int[] arr){
        return sortOf(Arrays.stream(arr).boxed().toArray(Integer[]::new));
    }

    @Override
    public Integer[] sortOf(Integer[] sourceArray){
        Integer[] arr = Arrays.copyOf(sourceArray,sourceArray.length);
        return sort(arr);
    }

    protected abstract Integer[] sort(Integer[] arr);
}
