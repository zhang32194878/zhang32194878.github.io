package isort;/*
 * @author zq
 */

public class XierSort extends BaseIntSort{

    @Override
    public Integer[] sort(Integer[] arr) {
        //希尔排序
        xierSort(arr);

        return arr;
    }

    private static void xierSort(Integer[] arr){
        int length = arr.length;
        for (int gap = length / 2; gap > 0; gap /= 2) {

            for (int i = gap; i < length; i++) {

                int temp = arr[i]; // 记录要插入的数据
                int j = i; //记录要插入的位置

                while(j >= gap && arr[j - gap] > temp) {
                    arr[j] = arr[j - gap]; //给要插入的数据挪位置
                    j -= gap;
                }
                if(j != i){
                    arr[j] = temp;
                }
            }
        }
    }
}
