package isort;/*
 * @author zq
 */

public class QuickSort extends BaseIntSort{

    @Override
    public Integer[] sort(Integer[] arr) {
        //选择排序
        int length = arr.length;
        quickSort(arr,0,length-1);
        return arr;
    }

    private static void quickSort(Integer[] arr, int left, int right) {
        int l = left;
        int r = right;
        int pivot = arr[(left + right) / 2];

        //从左右两端开始找比基准值大或小的数
        while(l < r) {
            while(arr[l] < pivot) {
                ++l;
            }

            while(arr[r] > pivot) {
                --r;
            }

            //左右都没有找到跳出循环
            if (l >= r) {
                break;
            }

            //找到了交换两个数的位置然后继续循环
            int temp = arr[l];
            arr[l] = arr[r];
            arr[r] = temp;


            //左右找到的数量不一定相同,左右两个指针不一定同时到达中间位置,但是总会有一边到达中间位置,
            // 那么另一边就可能出现两种情况
            //1. 还有可以交换的元素,那么上面的while循环还是生效的
            //2. 没有可交换的循环,而且还没有到达中间点,那么就靠下面的if将这一边拉到中间点,来退出循环
            if (arr[l] == pivot) {
                --r;
            }

            if (arr[r] == pivot) {
                ++l;
            }
        }

        //在这里保证l要大于r这样递归就没有重复的地方
        if (l == r) {
            ++l;
            --r;
        }

        //向左递归
        if (left < r) {
            quickSort(arr, left, r);
        }

        //向右递归
        if (right > l) {
            quickSort(arr, l, right);
        }

    }
}