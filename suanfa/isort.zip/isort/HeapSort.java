package isort;/*
 * @author zq
 */

public class HeapSort extends BaseIntSort{

    @Override
    public Integer[] sort(Integer[] arr) {

        heapSort(arr);

        return arr;
    }

    private static void heapSort(Integer[] arr) {

        //调整数组为一个大顶堆
        for(int i = arr.length / 2 - 1; i >= 0; --i) {
            adjustHeap(arr, i, arr.length);
        }

        for(int j = arr.length - 1; j > 0; --j) {
            //缩小数组,将顶首与尾进行交换
            //交换后只有顶部的部分是乱序的所以只需要调整一次即可
            int temp = arr[j];
            arr[j] = arr[0];
            arr[0] = temp;
            adjustHeap(arr, 0, j);
        }

    }
    private static void adjustHeap(Integer[] arr, int i, int length) {
        int temp = arr[i];

        //i*2+1为左子节点, k = k * 2 + 1下一个左子节点
        for(int k = i * 2 + 1; k < length; k = k * 2 + 1) {
            if (k + 1 < length && arr[k] < arr[k + 1]) {//存在右子节点,而且柚子节点还大
                ++k;//跳到右子节点
            }

            if (arr[k] <= temp) {
                break;
            }

            arr[i] = arr[k];
            i = k;
        }

        arr[i] = temp;
    }
}

