package isort;/*
 * @author zq
 */

public class ISortUtils {

    private static BaseIntSort baseIntSort;

    private static Integer[] baseSort(Integer[] arr){
        return baseIntSort.sortOf(arr);
    }
    private static Integer[] baseSort(int[] arr){
        return baseIntSort.sortOf(arr);
    }

    public static Integer[] bubbleSortOf(Integer[] arr){
        baseIntSort = new BubbleSort();
        return baseSort(arr);
    }

    //做个兼容int[]类型下面的都一样不多写了
    public static Integer[] bubbleSortOf(int[] arr){
        baseIntSort = new BubbleSort();
        return baseSort(arr);
    }


    public static Integer[] chooseSortOf(Integer[] arr){
        baseIntSort = new ChooseSort();
        return baseSort(arr);
    }

    public static Integer[] insertSort(Integer[] arr){
        baseIntSort = new InsertSort();
        return baseSort(arr);
    }

    public static Integer[] heapSort(Integer[] arr){
        baseIntSort = new HeapSort();
        return baseSort(arr);
    }

    public static Integer[] mergeSort(Integer[] arr){
        baseIntSort = new MergeSort();
        return baseSort(arr);
    }

    public static Integer[] quickSort(Integer[] arr){
        baseIntSort = new QuickSort();
        return baseSort(arr);
    }

    public static Integer[] radixSort(Integer[] arr){
        baseIntSort = new RadixSort();
        return baseSort(arr);
    }

    public static Integer[] xierSort(Integer[] arr){
        baseIntSort = new XierSort();
        return baseSort(arr);
    }

}
