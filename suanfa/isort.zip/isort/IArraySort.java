package isort;

public interface IArraySort<T>{

    T[] sortOf(T[] arr);
}
