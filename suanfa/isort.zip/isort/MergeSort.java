package isort;/*
 * @author zq
 */

public class MergeSort extends BaseIntSort{

    @Override
    public Integer[] sort(Integer[] arr) {
        //归并排序
        int length = arr.length;
        mergeSort( arr, 0, length - 1, new int[length]);
        return arr;
    }

    private static void mergeSort(Integer[] arr, int left, int right, int[] temp) {
        if (left < right) {
            int mid = (left + right) / 2;
            //向左递归
            mergeSort(arr, left, mid, temp);
            //向右递归
            mergeSort(arr, mid + 1, right, temp);
            //进行处理
            merge(arr, left, mid, right, temp);
        }

    }

    private static void merge(Integer[] arr, int left, int mid, int right, int[] temp) {
        int i = left;
        int j = mid + 1;
        int t = 0; //记录temp最后一个值的索引位置

        //以mid为分界的两个数组(此时已经有序),按大小放入temp中
        while(i <= mid && j <= right) {
            if (arr[i] < arr[j]) {
                temp[t] = arr[i];
                ++t;
                ++i;
            } else {
                temp[t] = arr[j];
                ++t;
                ++j;
            }
        }

        //由于左右放入的多少不一样,某一边会有剩下的,将剩下的直接放在后面
        while(i <= mid) {
            temp[t] = arr[i];
            ++t;
            ++i;
        }

        while(j <= right) {
            temp[t] = arr[j];
            ++t;
            ++j;
        }

        t = 0;

        //将合并好的数组覆盖两个数组成一个有序的数组,并向上回溯
        for(int tempLeft = left; tempLeft <= right; ++tempLeft) {
            arr[tempLeft] = temp[t];
            ++t;
        }
    }
}
